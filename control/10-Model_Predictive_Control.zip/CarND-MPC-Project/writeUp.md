## Model Predictive Control (MPC) Project 

### The Model

The model I used is a simplification of dynamic models -- a kinematic model that ignores tire forces, gravity and mass. Because it's more tractable than the complex dynamic model.

The kinematic model describes how the state changes over time based on previous state and current actuator inputs. Here is the model equation:

```
x[t+1] = x[t] + v[t] * cos(psi[t]) * dt
y[t+1] = y[t] + v[t] * sin(psi[t]) * dt
psi[t+1] = psi[t] + v[t] / Lf * delta[t] * dt
v[t+1] = v[t] + a[t] * dt
cte[t+1] = f(x[t]) - y[t] + v[t] * sin(epsi[t]) * dt
epsi[t+1] = psi[t+1] - psi_des[t] + v[t] * delta[t] / Lf * dt
```

The states contain the vehicle's coordinates (x and y), orientation angle (psi), velocity (v), cross track error (cte) and orientation error (epsi). The actuators contain the acceleration (a) and steering angle (delta). 

Note that Lf measures the distance between the center of mass of the vehicle and it's front axle. The larger the vehicle, the slower the turn rate.

### Timestep Length and Elapsed Duration (N & dt)

N is the number of timesteps and dt is how much time elapses between actuations. The multiplication of N and dt defines the prediction horizon, which is the duration over which future predictions are made.

N determines the number of variables optimized by the MPC. The larger N, the slower vehicle runs. When I increase N from 10 to 20, the CPU shots up immediately and the simulator got stuck sometimes. When I decrease N to 5, it seems that the program can not find a optimal trajectory for the vehicle and the car runs out of the track very quickly.

MPC attempts to approximate a continuous reference trajectory by means of discrete paths between actuations. If dt is too large, the generated path cannot approximate the reference trajectory very well. If dt is too small, the computation cost will increase significantly while the generated path does not improve very much.

After several times trail-and-error, I decided to use (10, 0.1) for (N, dt).

### Polynomial Fitting and MPC Preprocessing

The waypoints are transformed from map coordinate to vehicle coordinate. And then, a 3-order polynomial is used to fit the waypoints. Part of the current states (x, y coordinates and velocity) of the vehicle will be all 0, so the psi_des variable can be calculated as `atan(coeff[1])` even if the 3-order polynomial is applied.

Note that the sign of delta between our program and the simulator is different, so I modified the update equation of steering angle.

### Model Predictive Control with Latency

My approach to handle latency is to obtain a new state using the kinematic model from the current state for the duration of the latency. The new state is then used as the initial state for MPC.
